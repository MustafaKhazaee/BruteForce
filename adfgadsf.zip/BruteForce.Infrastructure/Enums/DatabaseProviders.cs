﻿
namespace BruteForce.Infrastructure.Enums;

public enum DatabaseProviders
{
    SQLServer,
    PostgreSQL,
}
