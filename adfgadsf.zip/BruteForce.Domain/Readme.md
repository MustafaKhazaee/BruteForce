﻿<h1>BruteForce.Domain</h1>
<p>
	Provides useful classes and interfaces to For Generic Repository, Auditing, Multi-tenancy and DDD.
</P>