﻿namespace BruteForce.Domain.Interfaces;

public interface IApplicationDbContext
{
}
