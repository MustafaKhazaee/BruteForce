﻿
namespace BruteForce.Domain.Interfaces;

public interface IHasTenant
{
    public long TenantId { set; get; }

    public IHasTenant SetTenantId(int tenantId);
}